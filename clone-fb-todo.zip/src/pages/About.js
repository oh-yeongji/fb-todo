const About = () => {
  return (
    <div className="p-6 mt-5 shadow rounded bg-white text-[#0891b2]">
      About/
    </div>
  );
};

export default About;
